/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator;
import java.util.ArrayList;

/**
 *
 * @author ramprasad
 */
public class Expression {
    
     public static String Solve(String Question) {
        String[] arr = Question.split("");

        ArrayList<String> list = new ArrayList<String>();

        for (int i = 0; i < arr.length; i++) 
        {
            list.add(arr[i]);
        }

        for (int j = 0; j < list.size(); j++) 
        {
            if (list.get(j).equals("÷")) 
            {
                String ad = String.valueOf(Integer.parseInt(list.get(j - 1)) / Integer.parseInt(list.get(j + 1)));
                list.remove(j);
                list.remove(j);
                list.set(j - 1, ad);
                j = -1;
            }
        }

        for (int k = 0; k < list.size(); k++) 
        {
            if (list.get(k).equals("×")) 
            {
                String ad = String.valueOf(Integer.parseInt(list.get(k - 1)) * Integer.parseInt(list.get(k + 1)));
                list.remove(k);
                list.remove(k);
                list.set(k - 1, ad);
                k = -1;
            }
        }

        for (int p = 0; p < list.size(); p++) 
        {
            if (list.get(p).equals("+")) 
            {
                String ad = String.valueOf(Integer.parseInt(list.get(p - 1)) + Integer.parseInt(list.get(p + 1)));
                list.remove(p);
                list.remove(p);
                list.set(p - 1, ad);
                p = -1;
            }
        }

        for (int x = 0; x < list.size(); x++) 
        {
            if (list.get(x).equals("-")) 
            {
                String ad = String.valueOf(Integer.parseInt(list.get(x - 1)) - Integer.parseInt(list.get(x + 1)));
                list.remove(x);
                list.remove(x);
                list.set(x - 1, ad);
                x = -1;
            }
        }

        return list.get(0); 
    }
     
}
