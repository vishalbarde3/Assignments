/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.vehicle;

/**
 *
 * @author RAMPRASAD
 */
class Vehicle1 {
    String brand;
    String model;
    int speed;
    String fuelType;
    int capacity;

    // Constructor
    Vehicle1(String brand, String model, int speed, String fuelType, int capacity) {
        this.brand = brand;
        this.model = model;
        this.speed = speed;
        this.fuelType = fuelType;
        this.capacity = capacity;
    }

    void start() {
        System.out.println(brand + " " + model + " is starting...");
    }

    void stop() {
        System.out.println(brand + " " + model + " is stopping...");
    }

    void refuel() {
        System.out.println("Refueling " + fuelType + "...");
    }

    void displayInfo() {
        System.out.println("Brand: " + brand + ", Model: " + model + ", Speed: " + speed + " km/h, Fuel: " + fuelType);
    }
}
