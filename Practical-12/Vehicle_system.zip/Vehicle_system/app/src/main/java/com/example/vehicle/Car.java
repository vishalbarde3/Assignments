/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.vehicle;

/**
 *
 * @author RAMPRASAD
 */
class Car extends Vehicle1 {
    int numDoors;
    boolean hasAirConditioning;
    boolean hasSunroof;

    Car(String brand, String model, int speed, String fuelType, int capacity, int numDoors, boolean hasAC, boolean hasSunroof) {
        super(brand, model, speed, fuelType, capacity);
        this.numDoors = numDoors;
        this.hasAirConditioning = hasAC;
        this.hasSunroof = hasSunroof;
    }

    void enableAC() {
        if (hasAirConditioning) {
            System.out.println("Air conditioning enabled.");
        } else {
            System.out.println("This car does not have AC.");
        }
    }

    void openSunroof() {
        if (hasSunroof) {
            System.out.println("Sunroof opened.");
        } else {
            System.out.println("No sunroof available.");
        }
    }
}
