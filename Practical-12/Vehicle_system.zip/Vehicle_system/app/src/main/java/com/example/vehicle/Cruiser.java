/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.vehicle;

/**
 *
 * @author RAMPRASAD
 */
class Cruiser extends Bike {
    boolean hasComfortSeat;

    Cruiser(String brand, String model, int speed, String fuelType, int capacity, boolean hasStorage, boolean isElectric, boolean hasComfortSeat) {
        super(brand, model, speed, fuelType, capacity, hasStorage, isElectric);
        this.hasComfortSeat = hasComfortSeat;
    }

    void enableCruiseControl() {
        System.out.println(model + " cruise control activated.");
    }
}