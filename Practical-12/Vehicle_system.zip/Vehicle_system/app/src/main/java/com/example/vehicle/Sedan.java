/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.vehicle;

/**
 *
 * @author RAMPRASAD
 */
class Sedan extends Car {
    boolean isLuxury;

    Sedan(String brand, String model, int speed, String fuelType, int capacity, int numDoors, boolean hasAC, boolean hasSunroof, boolean isLuxury) {
        super(brand, model, speed, fuelType, capacity, numDoors, hasAC, hasSunroof);
        this.isLuxury = isLuxury;
    }

    void activateAutoPilot() {
        System.out.println(model + " autopilot mode activated.");
    }
}